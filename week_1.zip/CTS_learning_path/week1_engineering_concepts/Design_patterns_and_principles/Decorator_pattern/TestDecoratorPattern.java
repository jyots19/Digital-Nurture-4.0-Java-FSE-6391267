public class TestDecoratorPattern {
    public static void main(String[] args) {
        // Basic email notification
        Notifier notifier1 = new EmailNotifier();
        System.out.println("---- Basic Email ----");
        notifier1.send("Hello via Email!");

        // Email + SMS
        Notifier notifier2 = new SMSNotifierDecorator(new EmailNotifier());
        System.out.println("\n---- Email + SMS ----");
        notifier2.send("Hello via Email and SMS!");

        // Email + SMS + Slack
        Notifier notifier3 = new SlackNotifierDecorator(
                                new SMSNotifierDecorator(
                                    new EmailNotifier()));
        System.out.println("\n---- Email + SMS + Slack ----");
        notifier3.send("Hello via Email, SMS, and Slack!");
    }
}
