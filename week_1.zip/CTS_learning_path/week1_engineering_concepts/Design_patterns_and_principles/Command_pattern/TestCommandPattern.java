public class TestCommandPattern {
    public static void main(String[] args) {
        Light livingRoomLight = new Light(); // Receiver

        Command lightOn = new LightOnCommand(livingRoomLight);
        Command lightOff = new LightOffCommand(livingRoomLight);

        RemoteControl remote = new RemoteControl(); // Invoker

        // Turn light ON
        remote.setCommand(lightOn);
        remote.pressButton();

        // Turn light OFF
        remote.setCommand(lightOff);
        remote.pressButton();
    }
}
