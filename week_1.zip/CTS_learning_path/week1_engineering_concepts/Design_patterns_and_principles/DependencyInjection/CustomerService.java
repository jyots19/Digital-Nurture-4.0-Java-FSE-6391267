public class CustomerService {
    private CustomerRepository customerRepository;

    // Constructor-based dependency injection
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public void showCustomerDetails(String id) {
        String customerInfo = customerRepository.findCustomerById(id);
        System.out.println("Customer Info: " + customerInfo);
    }
}
