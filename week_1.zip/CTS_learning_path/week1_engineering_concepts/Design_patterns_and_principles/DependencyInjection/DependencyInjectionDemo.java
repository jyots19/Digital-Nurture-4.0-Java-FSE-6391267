public class DependencyInjectionDemo {
    public static void main(String[] args) {
        // Step 1: Create the repository
        CustomerRepository repository = new CustomerRepositoryImpl();

        // Step 2: Inject it into the service
        CustomerService service = new CustomerService(repository);

        // Step 3: Use the service
        service.showCustomerDetails("C101");
    }
}
