public class RazorpayGateway {
    public void doTransaction(double amount) {
        System.out.println("Processing ₹" + amount + " via Razorpay.");
    }
}
